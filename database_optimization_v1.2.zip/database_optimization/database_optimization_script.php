<!-- /*----------------------
  Developed by Tushar Gabhane. 
  Contact no. +91 9404114775 
  Email: tushargabhane3@gmail
------------------------*/ -->

<!DOCTYPE html>
<html lang="zxx">
<head>
   <title>Database Optimisation -PHP</title>
   <meta name="Author" content="Tushar Gabhane">
   <meta charset="UTF-8">
   <meta name="theme-color" content="#5f5f63">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script
        src="https://code.jquery.com/jquery-3.5.1.min.js"
        integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
        crossorigin="anonymous"></script>
  <!-- Stylesheets -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/style.css"/>
  <link rel="stylesheet" href="css/font.css"/>

</head>
  <body>
      <div class="container">
        <h1> Simple PHP script to rearrange database row (count)</h1>
        <h5 style="float: right;">-Developed by Tushar Gabhane.</h5>
       <br><h3> Note: 
              <br> 1) Please ensure that no other dependency on id
              <br> 2) Please Backup your database if you are using 1st time </h3>
        <div class="wrapper wrapper--w960" style="padding-top: 4%;">
          <div class="card card-3">
            <div class="card-heading"></div>
              <div class="card-body">
                <h2 class="title" style="color: #fff; font-size: 32px;">Rearrange Database Row (id)</h2>
                 
                    <div class="input-group">
                      ServerName:* <input class="input--style-3" type="text" placeholder="localhost" name="servername" required id="servername">
                    </div>
                    <div class="input-group">
                       UserName:* <input class="input--style-3" type="text" placeholder="root" name="username" required id="username">
                    </div>
                    <div class="input-group">
                      Password:<input class="input--style-3" type="username" placeholder="leave blank in localhost" name="password" id="password">
                    </div>
                    <div class="input-group">
                      Database Name:* <input class="input--style-3" type="text" placeholder="Your DB Name" name="database_name" required id="database_name">
                    </div>
                    <div class="input-group">
                      Table Name:* <input class="input--style-3" type="text" placeholder="DB table name" name="table_name" required id="table_name">
                    </div>
                    <div class="input-group">
                      Column Name:* <input class="input--style-3" type="text" placeholder="id" name="column_name" required id="column_name">
                    </div>
                    <div class="input-group">
                      Row Limit:* <input class="input--style-3" type="number" placeholder="1000" name="row_limit" required id="row_limit">
                    </div>
                    <div class="p-t-10">
                      <button class="btn btn--pill btn--green" type="submit" id="submit" name="submit" value="submit" onclick="myFunction()">Submit</button>
                    </div>
                 
              </div>
          </div>
        </div>
      </div>
   
    <div id="table">
      <div id="inside_table"></div>
    </div>

    <!-- Footer section -->
      <footer>
        <div class="agilefooterwthree" id="agilefooterwthree">
          <div class="container">
            <div class="agilefooterwthreebottom">
              <div class="col-md-12 agilefooterwthreebottom-grid agilefooterwthreebottom-grid1">
                <div class="copyright">
                  <div class="col-md-6 col-sm-6 align-self-center">
                    <p>Made in India
                    <br>Developed by Tushar Gabhane.</p>
                  </div>
                  <div class="col-md-6 col-sm-6 align-self-center">
                    <p>Contact no. +91 9404114775 
                    <br>Email: tushargabhane3@gmail</p>
                  </div>
                </div>
              </div>
             
              </div>
            </div>
          </div>
        </div>
      </footer>
    <!-- Footer section end -->

      <script type="text/javascript">
           console.log('Design and coded by Tushar Gabhane');    
           function myFunction() {
  var elmnt = document.getElementById("inside_table");
  elmnt.scrollIntoView();
}

     </script>
      <script>
          $("#submit").click(function() {
              // alert(this.id); 
              console.log('Clicked');
              let servername  = $('#servername').val();
              let username    = $('#username').val();
              let password    = $('#password').val();
              let database_name = $('#database_name').val();
              let table_name = $('#table_name').val();
              let column_name = $('#column_name').val();
              let row_limit = $('#row_limit').val();



              if(servername  !=  '' && username != '' && database_name != '' && table_name != '' && column_name != '' && row_limit != '' ){

                var formData = new FormData();
                formData.append('servername',servername);
                formData.append('username',username);
                formData.append('database_name',database_name);
                formData.append('table_name',table_name);
                formData.append('column_name',column_name);
                formData.append('row_limit',row_limit);
                formData.append('password',password);


                $.ajax({
                       
                      url:"code.php",

                       type:'POST',
                       data:formData,
                       cache: false,
                       contentType: false,
                       processData: false,

                      beforeSend: function(){
                            $('#table').html("LOADING....!");
                            console.log("loader start");
                        },
                       success:  function (data) {
                           $('#table').html(data);
                           console.log(date);                       }
                 });

              }else{
                alert("All Fileds are Required");
              }
              
          });
      </script>
  </body>
</html>