
    <?php
      if ( isset($_POST['servername']) && isset($_POST['username']) && isset($_POST['database_name']) && isset($_POST['table_name']) && isset($_POST['column_name'])  && isset($_POST['row_limit']))
      {

        $sname = $uname = $pass = $dname = $tname = $rlimit = "";

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
          $sname = $_POST["servername"];
          $uname = $_POST["username"];
          $pass =  $_POST["password"];
          $dname = $_POST["database_name"];
          $tname = $_POST["table_name"];
          $column_name=$_POST["column_name"];
          $r_limit = $_POST["row_limit"];
        } 


        $servername = "$sname";
        $username = "$uname";
        $password = "$pass";
        $dbname = "$dname";

       // Create connection
            $con = new mysqli($servername, $username, $password, $dbname);
    			// Check connection
    			if (mysqli_connect_errno())
    			  {
    				echo "Failed to connect to MySQL: " . mysqli_connect_error();
    				exit;
    			  }
    			 	$conn = $con;

          	$sql = "SELECT * FROM `$tname` ORDER BY `$column_name` ASC LIMIT $r_limit";
            $result=mysqli_query($conn, $sql);
                  $counter='';
    ?>
      <div class="container">
        <h2 style="text-align: center;color: #fff;margin-top: 5%;">Output Table</h2>
            
          <div class="table-responsive-sm" style="overflow-x: auto">   <table class="table table-bordered">
              <thead class="thead-dark">
                <tr>
                  <th>Sr.No.</th>
                  <th>Table Name</th>
                  <th>Column Name</th>
                  <th>Old ID</th>
                  <th>New ID</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                
    <?php

        if ($result->num_rows > 0) {
          while($row = mysqli_fetch_array($result))                         
    			{
    				 $counter++;	    	 
    				  $id=$row["$column_name"];

    				$update_sql="UPDATE `$tname` SET `$column_name`='$counter' WHERE `$column_name`='$id'";
    				
  				if ($conn->query($update_sql) === TRUE) {
  				   $Status="updated successfully";
  				}else {
  				   $Status="Error: " . $conn->error;
  				}
    ?>        
            <tr>
              <td><?php echo $counter; ?></td>
              <td><?php echo $tname; ?></td>
              <td><?php echo $column_name; ?></td>
              <td><?php echo $id; ?></td>
              <td><?php echo $counter; ?></td>
               <td><?php echo $Status; ?></td>
            </tr>
    <?php
			    }
    ?>         
              </tbody>
            </table>
          </div>
        </div>
    <?php  
        }
        if ($conn->query($update_sql) === TRUE) {
             
          
          $reset_sql = "SELECT * FROM `$tname` ORDER BY `$column_name` DESC LIMIT 1";
              $reset_result=mysqli_query($conn, $reset_sql);
              if ($reset_result->num_rows > 0) {
                while($row = mysqli_fetch_array($reset_result))                         
                {         
                 $last_id=$row["$column_name"];
                 echo '<h4 style="text-align:center;">Last Entry in &nbsp;'.$column_name .'&nbsp; are &nbsp;'. $last_id .'</h4>';    
                 ++$last_id;
                 $alter_sql = "ALTER TABLE `$tname` AUTO_INCREMENT = $last_id";

                 if ($conn->query($alter_sql) === TRUE) {
                  $al_Status="Auto increment is set from &nbsp;". $last_id ."&nbsp; onwards";
                  }else {
                  $al_Status="Auto increment is not set from &nbsp;". $last_id ."&nbsp; onwards" . $conn->error;
                 } 
                 echo '<h4 style="text-align:center;">'.$al_Status.'</h4>';           
                }
              }
        }
      }
       
    ?>

    